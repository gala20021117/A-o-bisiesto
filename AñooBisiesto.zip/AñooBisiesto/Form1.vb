﻿Public Class Form1

    Private Sub btnContinuar_Click(sender As Object, e As EventArgs) Handles btnContinuar.Click
        Dim nombre As String

        nombre = txtNombre.Text

        If nombre = "" Then
            MsgBox("Ingrese su nombre por favor", MsgBoxStyle.Critical)

        Else
            Form2.Show()
            nombre = txtNombre.Text

        End If
    End Sub
End Class
