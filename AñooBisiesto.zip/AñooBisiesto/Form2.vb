﻿Public Class Form2

    Private Sub Año_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim nombre1 As String
        nombre1 = Form1.txtNombre.Text
        lbBienvenido.Text = " Bienvenido/a  " + nombre1

    End Sub

    Function AñoBisiesto(año As Integer) As Boolean
        Dim EsBisiesto As Boolean

        If año Mod 4 = 0 Or año Mod 100 = 0 Or año Mod 400 = 0 Then
            'El año si es bisiesto
            EsBisiesto = True
        Else
            'El año no es bisiesto
            EsBisiesto = False

        End If
        Return EsBisiesto


    End Function

    Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click
        Dim año As Integer = Val(txtAño.Text)

        Dim mensaje As String
        Dim YesOrNo As Boolean

        YesOrNo = AñoBisiesto(año)

        If YesOrNo = True Then
            mensaje = "¡El año que ingresó es bisiesto!"
        Else
            mensaje = "El año que ingresó no es bisiesto"
        End If

        lb1.Text = mensaje
        lb2.Text = "¡Gracias por usar mi programa!"
        lb3.Text = "Mi nombre es Melanie Galaretto"
        lb4.Text = "Soy alumna de 3° Informatica de UTU"
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End
    End Sub

End Class